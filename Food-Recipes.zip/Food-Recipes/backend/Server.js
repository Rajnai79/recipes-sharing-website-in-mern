const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const registerRoute = require('./routes/Userregister');
const authRoute = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/foodrecipe')
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.log('Failed to connect to MongoDB', err);
    });


app.use('/userregister', registerRoute);
app.use('/auth', authRoute);

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
