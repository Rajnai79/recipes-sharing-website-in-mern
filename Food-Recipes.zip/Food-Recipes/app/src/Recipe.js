import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';  
import './Recipe.css';

const heartIcon = `${process.env.PUBLIC_URL}/images/favorite-icon.png`; 
const heartFilledIcon = `${process.env.PUBLIC_URL}/images/favorite-icon-filled.png`;
const Recipes = () => {
  const [selectedCuisine, setSelectedCuisine] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState([]);
  const navigate = useNavigate();  

  useEffect(() => {
    const savedFavorites = JSON.parse(localStorage.getItem('favorites')) || [];
    setFavorites(savedFavorites);
  }, []);

  const handleCuisineSelect = (cuisine) => setSelectedCuisine(cuisine);
  const handleSearchChange = (event) => setSearchQuery(event.target.value.toLowerCase());

  const toggleFavorite = (recipe) => {
    const isFavorite = favorites.some(fav => fav.name === recipe.name);
    const updatedFavorites = isFavorite ? favorites.filter(fav => fav.name !== recipe.name) : [...favorites, recipe];
    setFavorites(updatedFavorites);
    localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
  };

  const recipes = { 
    Punjabi: [
      { name: "Paneer Tawa Masala", img: "/punjabi/paneer tawa masala.jpeg" },
      { name: "Matar Paneer", img: "/punjabi/matar_paneer.jpeg" },
      { name: "Paneer Kadai Butter", img: "/punjabi/paneer kadai butter.jpeg" }, 
      { name: "Paneer Butter Masala", img: "/punjabi/paneer butter masala.webp" },
      { name: "Kadai Paneer", img: "/punjabi/kadai paneer.jpeg" },
      { name: "Paneer Bhurji", img: "/punjabi/paneer bhurji.jpeg" },
      { name: "Paneer Handi", img: "/punjabi/paneer handi.jpeg" },
      { name: "Paneer Makhani", img: "/punjabi/paneer makhani.jpeg" },
      { name: "Paneer Tikka Masala", img: "/punjabi/paneer tikka masala.jpeg" },
      { name: "Shahi Paneer", img: "/punjabi/shahipaneer.jpeg" },
      { name: "Butter Naan", img: '/punjabi/butter_naan.jpeg' }, 
      { name: "Chili Paneer", img: '/punjabi/chilli_paneer.jpeg' }, 
      { name: "Garlic Butter Paneer Chilli", img: '/punjabi/garlic_butter_paneer_chilli.jpeg' }, 
      { name: "Garlic Butter Naan", img: '/punjabi/garlic_butter_naan.jpeg' }, 
      { name: "Paneer Kadai", img: '/punjabi/paneer_kadai.jpeg' }, 
      { name: "Paneer Kaju Butter", img: '/punjabi/paneer_kaju_butter.jpeg' }, 
      { name: "Paneer Lababdar", img: '/punjabi/paneer_lababdar.jpeg' }, 
      { name: "Paneer MA10", img: '/punjabi/paneer_maio.jpeg' }, 
      { name: "Paneer Tadka", img: '/punjabi/paneer_tadka.jpeg' } 
    ],
    
    NorthIndian: [
      { name: 'Rajma Chawal', img: '/North Indian/rajma chawal.jpeg' },
      { name: 'Kadhi Pakora Rice', img: '/North Indian/kadhi pakora rice.jpeg' },
      { name: 'Malpua', img: '/North Indian/3.jpeg' },
      { name: 'Gond Ke Laddu', img: '/North Indian/7.jpeg' },
      { name: 'Dum Aloo', img: '/North Indian/6.jpeg' },
      { name: 'Gajar Ka Halwa', img: '/North Indian/1.jpeg' },
      { name: 'Aloo Chaat', img: '/North Indian/5.jpeg' },
      { name: 'Choley Bhature', img: '/North Indian/choley bhature.jpeg' }, 
      { name: 'Choley Butter Gravy', img: '/North Indian/choley_butter_gravy_poodi.jpeg' }, 
      { name: 'Gobi Masala', img: '/North Indian/gobi_masala.jpeg' }, 
      { name: 'Gulab Jamun', img: '/North Indian/gulab_jamun.jpeg' }, 
      { name: 'Matar Aloo Gravy', img: '/North Indian/matar_aloo_gravy.jpeg' }, 
      { name: 'Poori Aloo Bhaji', img: '/North Indian/poori_aloo_bhaji.jpeg' }, 
      { name: 'Poori Aloo Matar Bhaji', img: '/North Indian/poori_aloo_matar_bhaji.jpeg' }, 
      { name: 'Potato Aloo Gobi', img: '/North Indian/potato_aloo_gobi.jpeg' },
      { name: 'Rice Dal Fry', img: '/North Indian/rice_dal_fry.jpeg' }, 
      { name: 'Roti', img: '/North Indian/roti.jpeg' }, 
      { name: 'Samosa Green Chutney', img: '/North Indian/samosa_green_chutney.jpeg' }
    ],
    
    Gujarati: [
      { name: 'Masala Potato', img: '/Gujarati/masala potato.jpeg' },
      { name: 'Masala Khichdi', img: '/Gujarati/masala khichdi.jpeg' },
      { name: 'Dal Fry', img: '/Gujarati/dal fry.jpeg' },
      { name: 'Chapati Butter', img: '/Gujarati/chapati butter.jpeg' },
      { name: 'Bhindi', img: '/Gujarati/bhindi.jpeg' },
      { name: 'Aloo Gobi', img: '/Gujarati/aloo gobi.jpeg' },
      { name: 'Mix Vegetable', img: '/Gujarati/mix vegetable.jpeg' },
      { name: 'Moong Butter Masala', img: '/Gujarati/moong butter masala.jpeg' },
      { name: 'Patta Gobi', img: '/Gujarati/patta gobi.jpeg' },
      { name: 'Potato Curry', img: '/Gujarati/potato curry.jpeg' },
      { name: 'Sev Tameta', img: '/Gujarati/sev tameta.jpeg' },
      { name: 'Totha Tuver', img: '/Gujarati/totha tuver.jpeg' },
      { name: 'Patra', img: '/Gujarati/patra.jpeg' }, 
      { name: 'Pulao', img: '/Gujarati/pulla.jpeg' }, 
      { name: 'Thepla Dahi Masala', img: '/Gujarati/thepla dahi masala.jpeg' }, 
      { name: 'Thepla Garlic', img: '/Gujarati/thepla_garlic.jpg' }, 
      { name: 'White Dhokla', img: '/Gujarati/white dhokla.jpg' }, 
      { name: 'Dhokla Vati Dal Naylon', img: '/Gujarati/dhokla_vati_dal_naylon.jpeg' }, 
      { name: 'Fafda', img: '/Gujarati/fafda.png' }, 
      { name: 'Jalebi Pista', img: '/Gujarati/jalebi pista.jpeg' }, 
      { name: 'Paneer Naylon Dhokla', img: '/Gujarati/paneer naylon dhokla.jpeg' } 
    ],
    
    SouthIndian: [
      { name: 'Onion Rava Masala Dosa', img: '/South Indian/onion rava masala dosa.jpeg' },
      { name: 'Medu Vada', img: '/South Indian/medu vada.jpeg' }, 
      { name: 'Idli', img: '/South Indian/idli.jpeg' },
      { name: 'Dosa', img: '/South Indian/dosa.jpeg' },
      { name: 'Cheese Gotala Dosa', img: '/South Indian/cheese gotala dosa.jpeg' },
      { name: 'Butter Masala Dosa', img: '/South Indian/butter masala dosa.jpeg' },
      { name: 'Rava Dosa', img: '/South Indian/rava dosa.jpeg' },
      { name: 'Paneer Gotala Dosa', img: '/South Indian/paneer gotala dosa.jpeg' },
      { name: 'Upma', img: '/South Indian/upma.jpeg' },
      { name: 'Uttapam', img: '/South Indian/uttapam.jpeg' },
      { name: 'Tikdi Vada', img: '/South Indian/tikdi_vada.jpeg' }, 
      { name: 'Paper Masala Dosa', img: '/South Indian/paper_masala_dosa.jpeg' }, 
      { name: 'Masala Spicy Idli', img: '/South Indian/masala_spicy_idli.jpeg' }, 
      { name: 'Masala Idli', img: '/South Indian/masala_idali.jpeg' }, 
      { name: 'Masala Dosa', img: '/South Indian/masala_dosa.jpeg' }, 
      { name: 'Idli Mix', img: '/South Indian/idli_mix.jpeg' },
      { name: 'Idli Garlic', img: '/South Indian/idali_garlic.jpeg' }, 
      { name: 'Dal Sambhar', img: '/South Indian/dali_sambhar.jpeg' }, 
      { name: 'Cheese Masala Paneer Dosa', img: '/South Indian/cheese_masala_paneer_dosa.jpeg' },
      { name: 'Aloo Masala Dosa', img: '/South Indian/aloo masala dosa.jpeg' } 
    ],
    
    Chinese: [
      { name: "Dry Manchurian", img: "/Chinese/dry manchurian.webp" },
      { name: "Hakka Noodles", img: "/Chinese/hakka noodles.jpeg" },
      { name: "Manchurian Gravy", img: "/Chinese/manchurian gravy.jpeg" },
      { name: "Manchurian Paneer Dry", img: "/Chinese/manchurian paneer dry.webp" },
      { name: "Schezwan Manchurian Rice", img: "/Chinese/schezwan manchurian rice.jpeg" },
      { name: "Vegetable Manchurian Cheese Fried", img: "/Chinese/vegetable manchurian cheese fried.jpeg" },
      { name: "Manchurian Bhel", img: "/Chinese/manchurian bhel.jpeg" },
      { name: "Manchurian Noodles", img: "/Chinese/manchurian noodles.jpg" }
    ]
  };

  const filteredRecipes = recipes[selectedCuisine]?.filter(recipe =>
    recipe.name.toLowerCase().includes(searchQuery)
  );

  return (
    <div className="container">
    <div className="button-container">
      <button className="home-button" onClick={() => navigate('/home1')}>
        Back to Home
      </button>
      
      <button className="view-favorites-button" onClick={() => navigate('/favorites')}>
        View Favorites
      </button>
    </div>

      <h1>Select a Cuisine</h1>
      <div className="cuisine-buttons">
        {Object.keys(recipes).map((cuisine, index) => (
          <button key={index} onClick={() => handleCuisineSelect(cuisine)}>
            {cuisine}
          </button>
        ))}
      </div>

      <input
        type="text"
        placeholder="Search recipes..."
        value={searchQuery}
        onChange={handleSearchChange}
      />

      <div className={`cuisine-display ${selectedCuisine ? 'show' : ''}`}>
        {filteredRecipes && filteredRecipes.length > 0 ? (
          <div className="recipe-overview">
            {filteredRecipes.map((recipe, index) => (
              <div key={index} className="recipe-item">
                <span
                  className="favorite-icon"
                  onClick={(e) => {
                    e.stopPropagation(); 
                    toggleFavorite(recipe);
                  }}
                >
                  <img 
                    src={favorites.some(fav => fav.name === recipe.name) ? heartFilledIcon : heartIcon} 
                    alt="Favorite Icon" 
                    style={{ width: '65px', height: '65px' }} 
                  />
                </span>
                
                <Link to={`/recipe/${recipe.name}`}>
                  <img src={recipe.img} alt={recipe.name} />
                  <p>{recipe.name}</p>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p>No recipes found.</p>
        )}
      </div>
    </div>
  );
};

export default Recipes;
