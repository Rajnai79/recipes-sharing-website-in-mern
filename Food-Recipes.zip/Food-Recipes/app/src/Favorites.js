// Favorites.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const Favorites = () => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const savedFavorites = JSON.parse(localStorage.getItem('favorites')) || [];
    setFavorites(savedFavorites);
  }, []);

  return (
    <div className="containmier">
      <h1>Your Favorite Recipes</h1>
      <div className="recipe-overview">
        {favorites.length > 0 ? (
          favorites.map((recipe, index) => (
            <div key={index} className="recipe-item favorite-recipe">
              <Link to={`/recipe/${recipe.name}`}>
                <img src={recipe.img} alt={recipe.name} />
                <p>{recipe.name}</p>
              </Link>
            </div>
          ))
        ) : (
          <p>No favorite recipes yet.</p>
        )}
      </div>
    </div>
  );
};

export default Favorites;
