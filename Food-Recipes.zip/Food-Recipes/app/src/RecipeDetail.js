
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './RecipeDetail.css';

const recipes = [
    {
  name: 'Paneer Tawa Masala',
  img: '/punjabi/paneer tawa masala.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, finely chopped',
    '2 tomatoes, chopped',
    '1 tsp cumin seeds',
    '1 tbsp ginger-garlic paste',
    '1 tsp turmeric powder',
    '1 tsp garam masala',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomatoes, turmeric, coriander powder, and salt. Cook until oil separates.',
    'Add paneer cubes and cook for 5-7 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/bKqG9vTJNHU?feature=shared'
},
{
  name: 'Matar Paneer',
  img: '/punjabi/matar_paneer.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 cup green peas',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil, add cumin seeds, and sauté onions until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until oil separates.',
    'Add peas and paneer cubes, cook for 5-7 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/f2oVTs-bRGg?feature=shared'
},
{
  name: 'Paneer Kadai Butter',
  img: '/punjabi/paneer kadai butter.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, sliced',
    '2 tomatoes, chopped',
    '1 green bell pepper, sliced',
    '1 tsp cumin seeds',
    '1 tbsp ginger-garlic paste',
    '1 tsp garam masala',
    '2 tbsp butter',
    'Salt to taste',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat butter in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomatoes, bell pepper, garam masala, and salt. Cook until tomatoes soften.',
    'Add paneer cubes and cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/Lxz12zcGww8?feature=shared'
},
{
  name: 'Paneer Butter Masala',
  img: '/punjabi/paneer butter masala.webp',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '2 tbsp butter',
    '1 tsp garam masala',
    '1/2 cup cream',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat butter in a pan, add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomato puree, garam masala, and salt. Cook until the sauce thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/bUounn_Bmy4?feature=shared'
},
{
  name: 'Kadai Paneer',
  img: '/punjabi/kadai paneer.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, sliced',
    '2 tomatoes, chopped',
    '1 green bell pepper, sliced',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomatoes, bell pepper, garam masala, and salt. Cook until soft.',
    'Add paneer cubes and cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/vYv971NmwUM?feature=shared'
},
{
  name: 'Paneer Bhurji',
  img: '/punjabi/paneer bhurji.jpeg',
  ingredients: [
    '200g paneer, crumbled',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 green chili, chopped',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tbsp ginger-garlic paste',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and turmeric powder; cook until oil separates.',
    'Add crumbled paneer and green chili, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/KgW--wj5iBM?feature=shared'
},
{
  name: 'Paneer Handi',
  img: '/punjabi/paneer handi.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp cumin seeds',
    '1 tbsp ginger-garlic paste',
    '1 tsp garam masala',
    '1/2 cup cream',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a handi (clay pot), add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomatoes, garam masala, and salt; cook until the mixture thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/UFHWX3C02R4?feature=shared'
},
{
  name: 'Paneer Makhani',
  img: '/punjabi/paneer makhani.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '2 tbsp butter',
    '1/2 cup cream',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat butter in a pan, add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomato puree, garam masala, and salt; cook until the sauce thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/5uaKAWmNo_E?feature=shared'
},
{
  name: 'Paneer Tikka Masala',
  img: '/punjabi/paneer tikka masala.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp garam masala',
    '1/2 cup yogurt',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Marinate paneer in yogurt, garam masala, and salt for 30 minutes.',
    'Heat oil, add cumin seeds, and sauté onions until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomato puree and cook until the sauce thickens.',
    'Add marinated paneer and cook for 5-7 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/ZaUNzwr_KF0?feature=shared'
},
{
  name: 'Shahi Paneer',
  img: '/punjabi/shahipaneer.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '2 tbsp cashew nuts, soaked and ground',
    '2 tbsp cream',
    '1 tsp garam masala',
    '1 tbsp butter',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat butter in a pan, add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cashew paste, cook for a minute.',
    'Add tomato puree, garam masala, and salt; cook until the sauce thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/T9hQV22Uezw?feature=shared'
},
{
  name: 'Butter Naan',
  img: '/punjabi/butter_naan.jpeg',
  ingredients: [
    '2 cups all-purpose flour',
    '1/4 cup yogurt',
    '1 tsp baking powder',
    '1/2 tsp baking soda',
    '1 tbsp sugar',
    'Salt to taste',
    'Butter for brushing',
    'Water as needed'
  ],
  instructions: [
    'In a bowl, mix flour, baking powder, baking soda, sugar, and salt.',
    'Add yogurt and water to form a soft dough, knead for 5 minutes.',
    'Cover and let the dough rest for 2 hours.',
    'Roll out portions of the dough, cook on a hot tawa until golden brown.',
    'Brush with butter and serve hot.'
  ],
  video: 'https://youtu.be/H3tW-UFSojU?feature=shared'
},
{
  name: 'Chili Paneer',
  img: '/punjabi/chilli_paneer.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, diced',
    '1 green bell pepper, diced',
    '2 green chilies, slit',
    '1 tbsp soy sauce',
    '1 tbsp chili sauce',
    '1 tsp ginger-garlic paste',
    '1 tsp cornflour, mixed with water',
    'Salt to taste',
    'Oil for frying and cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Deep fry paneer cubes until golden brown and set aside.',
    'Heat oil in a pan, add onions, bell pepper, and green chilies, sauté for 2-3 minutes.',
    'Add ginger-garlic paste, soy sauce, chili sauce, and cornflour mixture. Cook until the sauce thickens.',
    'Add fried paneer and mix well.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/P7ZGxWKJkX8?feature=shared'
},
{
  name: 'Garlic Butter Paneer Chilli',
  img: '/punjabi/garlic_butter_paneer_chilli.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '1 green bell pepper, chopped',
    '2 green chilies, slit',
    '1 tbsp garlic, finely chopped',
    '2 tbsp butter',
    '1 tbsp soy sauce',
    '1 tbsp chili sauce',
    'Salt to taste',
    'Oil for frying',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Fry paneer cubes until golden and set aside.',
    'In a pan, heat butter, add garlic and sauté until golden brown.',
    'Add onions, bell pepper, and green chilies; sauté for 2-3 minutes.',
    'Add soy sauce, chili sauce, and salt. Mix well.',
    'Add paneer and stir fry for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/Ewr7ARdSybg?feature=shared'
},
{
  name: 'Garlic Butter Naan',
  img: '/punjabi/garlic_butter_naan.jpeg',
  ingredients: [
    '2 cups all-purpose flour',
    '1/4 cup yogurt',
    '1 tsp baking powder',
    '1/2 tsp baking soda',
    '1 tbsp sugar',
    'Salt to taste',
    '4 cloves garlic, finely chopped',
    'Butter for brushing',
    'Water as needed'
  ],
  instructions: [
    'In a bowl, mix flour, baking powder, baking soda, sugar, and salt.',
    'Add yogurt and water to form a soft dough, knead for 5 minutes.',
    'Cover and let the dough rest for 2 hours.',
    'Roll out portions of the dough, sprinkle chopped garlic on top, and cook on a hot tawa until golden brown.',
    'Brush with butter and serve hot.'
  ],
  video: 'https://youtu.be/YEFeLn7nlu0?feature=shared'
},
{
  name: 'Paneer Kadai',
  img: '/punjabi/paneer_kadai.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, sliced',
    '2 tomatoes, chopped',
    '1 green bell pepper, sliced',
    '1 tsp cumin seeds',
    '1 tbsp ginger-garlic paste',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a kadai, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and bell pepper. Cook until soft.',
    'Add paneer, garam masala, and salt. Stir and cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/vYv971NmwUM?feature=shared'
},
{
  name: 'Paneer Kaju Butter',
  img: '/punjabi/paneer_kaju_butter.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1/4 cup cashew nuts, soaked and ground to a paste',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tsp cumin seeds',
    '1 tbsp ginger-garlic paste',
    '1 tsp garam masala',
    '2 tbsp butter',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat butter and oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cashew paste, cook for a minute.',
    'Add tomato puree, garam masala, and salt; cook until the sauce thickens.',
    'Add paneer cubes and cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/473t-TdWKuo?feature=shared'
},
{
  name: 'Paneer Lababdar',
  img: '/punjabi/paneer_lababdar.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1/4 cup cashew nuts, soaked and ground to a paste',
    '1 tsp cumin seeds',
    '1 tsp garam masala',
    '2 tbsp cream',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cashew paste, cook for a minute.',
    'Add tomato puree, garam masala, and salt; cook until the sauce thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtu.be/1DbrPChGnpk?feature=shared'
},
{
  name: 'Paneer MA10',
  img: '/punjabi/paneer_maio.jpeg',
  ingredients: [
    '200g paneer, cubed',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp garam masala',
    '2 tbsp cream',
    'Salt to taste',
    'Oil for cooking',
    'Coriander leaves for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomato puree, garam masala, and salt; cook until the sauce thickens.',
    'Add paneer cubes and cream, cook for 5 minutes.',
    'Garnish with coriander leaves and serve hot.'
  ],
  video: 'https://youtube.com/shorts/lDmgAs7D5II?feature=shared'
},
{
  name: 'Rajma Chawal',
  img: '/North Indian/rajma chawal.jpeg',
  ingredients: [
    '1 cup rajma (kidney beans), soaked overnight',
    '2 cups basmati rice',
    '1 onion, finely chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp coriander powder',
    '1/2 tsp turmeric powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Pressure cook soaked rajma with water and salt until soft.',
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add tomato puree, turmeric, and coriander powder, and cook until oil separates.',
    'Add cooked rajma along with the water and simmer for 10-15 minutes.',
    'Cook rice separately and serve rajma over rice, garnished with coriander.'
  ],
  video: 'https://youtu.be/asY7cq6j0xE?feature=shared'
},
{
  name: 'Kadhi Pakora Rice',
  img: '/North Indian/kadhi pakora rice.jpeg',
  ingredients: [
    '1 cup yogurt',
    '2 tbsp gram flour (besan)',
    '1 onion, finely sliced',
    '1 green chili, chopped',
    '1 tsp cumin seeds',
    '1/2 tsp turmeric powder',
    '1/2 tsp red chili powder',
    'Salt to taste',
    'Oil for frying pakoras',
    'Fresh coriander for garnish',
    '1 cup basmati rice'
  ],
  instructions: [
    'Whisk yogurt and besan together, adding water to make a smooth batter.',
    'In a pan, heat oil, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden, then add turmeric and red chili powder.',
    'Pour in the yogurt-besan mixture, stirring continuously to avoid lumps.',
    'Simmer until the kadhi thickens.',
    'For the pakoras, mix sliced onions with gram flour, salt, and water to form a batter.',
    'Fry small spoonfuls of the batter in hot oil until golden and crispy.',
    'Add fried pakoras to the kadhi and cook for 5-7 minutes.',
    'Serve hot with steamed basmati rice.'
  ],
  video: 'https://youtu.be/3h15T-d6zHA?feature=shared'
},
{
  name: 'Malpua',
  img: '/North Indian/3.jpeg',
  ingredients: [
    '1 cup all-purpose flour (maida)',
    '1/2 cup semolina (sooji)',
    '1/2 cup sugar',
    '1/4 tsp fennel seeds',
    '1/4 tsp cardamom powder',
    '1/2 cup milk',
    'Oil for frying',
    'Chopped nuts for garnish',
    '1 cup sugar syrup'
  ],
  instructions: [
    'In a bowl, mix flour, semolina, sugar, fennel seeds, and cardamom powder.',
    'Add milk to make a thick batter and let it rest for 15-20 minutes.',
    'Heat oil in a pan, pour small amounts of batter to make round pancakes, and fry until golden brown.',
    'Dip the fried malpuas in sugar syrup for a minute, then remove and serve hot, garnished with chopped nuts.'
  ],
  video: 'https://youtu.be/aGS4LcMRZRU?feature=shared'
},
{
  name: 'Gond Ke Laddu',
  img: '/North Indian/7.jpeg',
  ingredients: [
    '1 cup whole wheat flour',
    '1/2 cup edible gum (gond)',
    '1/2 cup ghee',
    '1/2 cup sugar',
    '1/4 tsp cardamom powder',
    'Chopped nuts for garnish'
  ],
  instructions: [
    'Heat ghee in a pan, fry the gond until it puffs up, and set aside.',
    'In the same ghee, roast wheat flour until golden brown and aromatic.',
    'Grind the fried gond and mix it with roasted flour and sugar.',
    'Add cardamom powder and mix well.',
    'Shape the mixture into small laddus while still warm, garnished with nuts.'
  ],
  video: 'https://youtu.be/Sz5jGFUEV1I?feature=shared'
},
{
  name: 'Dum Aloo',
  img: '/North Indian/6.jpeg',
  ingredients: [
    '10 baby potatoes',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Boil baby potatoes and peel them.',
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add chopped onions and sauté until golden brown.',
    'Add ginger-garlic paste and cook for a minute.',
    'Add chopped tomatoes, coriander powder, and garam masala, and cook until the oil separates.',
    'Add boiled potatoes and cook on low heat until the gravy thickens.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/Ut9orfzu4n4?feature=shared'
},
{
  name: 'Gajar Ka Halwa',
  img: '/North Indian/1.jpeg',
  ingredients: [
    '4 cups grated carrots',
    '1 cup milk',
    '1/2 cup sugar',
    '1/4 cup ghee',
    '1/2 tsp cardamom powder',
    'Chopped nuts for garnish'
  ],
  instructions: [
    'Heat ghee in a pan and sauté the grated carrots for a few minutes.',
    'Add milk and cook the carrots until the milk is absorbed.',
    'Add sugar and continue cooking until the mixture thickens.',
    'Stir in cardamom powder and cook for a few more minutes.',
    'Garnish with chopped nuts and serve hot.'
  ],
  video: 'https://youtu.be/P0SNsqFtFMg?feature=shared'
},
{
  name: 'Aloo Chaat',
  img: '/North Indian/5.jpeg',
  ingredients: [
    '4 boiled potatoes, cubed',
    '1 onion, finely chopped',
    '1 tomato, chopped',
    '1 green chili, chopped',
    '1 tsp chaat masala',
    '1/2 tsp cumin powder',
    'Salt to taste',
    'Lemon juice',
    'Fresh coriander for garnish',
    'Tamarind chutney (optional)'
  ],
  instructions: [
    'Fry the boiled potato cubes until crispy and golden brown.',
    'In a bowl, mix the fried potatoes, chopped onions, tomatoes, and green chili.',
    'Sprinkle chaat masala, cumin powder, and salt over the mixture.',
    'Add lemon juice and mix well.',
    'Drizzle with tamarind chutney if desired and garnish with fresh coriander.'
  ],
  video: 'https://youtu.be/2qq5fmo54SE?feature=shared'
},
{
  name: 'Choley Bhature',
  img: '/North Indian/choley bhature.jpeg',
  ingredients: [
    '1 cup chickpeas, soaked overnight',
    '1 onion, finely chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp chole masala',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish',
    'For the bhature: 2 cups all-purpose flour, 1/4 cup yogurt, 1/2 tsp baking soda'
  ],
  instructions: [
    'Pressure cook the soaked chickpeas until soft and set aside.',
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices, and cook until oil separates.',
    'Add cooked chickpeas and simmer for 10 minutes.',
    'To make the bhature, knead the flour with yogurt and baking soda into a soft dough and let it rest for 30 minutes.',
    'Roll the dough into round shapes and deep-fry until golden brown.',
    'Serve hot choley with bhature and garnish with coriander.'
  ],
  video: 'https://youtu.be/FU1ZVLMbWjA?feature=shared'
},
{
  name: 'Choley Butter Gravy',
  img: '/North Indian/choley_butter_gravy_poodi.jpeg',
  ingredients: [
    '1 cup chickpeas, soaked overnight',
    '1 onion, finely chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tbsp butter',
    '1 tsp chole masala',
    '1 tsp garam masala',
    '1/2 cup cream',
    'Salt to taste',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Pressure cook the soaked chickpeas until soft and set aside.',
    'Heat butter in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices, and cook until the oil separates.',
    'Add cooked chickpeas, cream, and simmer for 10 minutes.',
    'Garnish with fresh coriander and serve hot with poori or rice.'
  ],
  video: 'https://youtu.be/3xY83nUI3Sw?feature=shared'
},
{
  name: 'Gobi Masala',
  img: '/North Indian/gobi_masala.jpeg',
  ingredients: [
    '1 medium cauliflower, cut into florets',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Blanch the cauliflower florets in hot water for a few minutes, then drain.',
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until the oil separates.',
    'Add the cauliflower florets and cook on low heat until the masala is well absorbed and the cauliflower is tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/mB6LH-GKNW4?feature=shared'
},
{
  name: 'Gulab Jamun',
  img: '/North Indian/gulab_jamun.jpeg',
  ingredients: [
    '1 cup khoya (milk solids)',
    '1/4 cup all-purpose flour',
    '1/4 tsp baking powder',
    '1 tbsp milk',
    'Oil or ghee for frying',
    'For the sugar syrup: 1 1/2 cups sugar, 1 1/2 cups water, 1/4 tsp cardamom powder, a few saffron strands'
  ],
  instructions: [
    'In a bowl, mix khoya, flour, and baking powder. Add milk to form a soft dough.',
    'Divide the dough into small balls and make sure there are no cracks.',
    'Heat oil or ghee in a deep pan and fry the dough balls on low heat until golden brown.',
    'In a separate pan, prepare sugar syrup by boiling sugar, water, cardamom, and saffron.',
    'Soak the fried gulab jamun in the hot sugar syrup for at least 30 minutes before serving.'
  ],
  video: 'https://youtu.be/Do9mk9mya_A?feature=shared'
},
{
  name: 'Matar Aloo Gravy',
  img: '/North Indian/matar_aloo_gravy.jpeg',
  ingredients: [
    '2 potatoes, cubed',
    '1 cup green peas (matar)',
    '1 onion, chopped',
    '2 tomatoes, pureed',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Boil the potatoes and green peas, and set aside.',
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices, and cook until the oil separates.',
    'Add boiled potatoes and peas, and simmer the gravy for a few minutes.',
    'Garnish with fresh coriander and serve hot with roti or rice.'
  ],
  video: 'https://youtu.be/gdhlkJWkOmo?feature=shared'
},
{
  name: 'Poori Aloo Bhaji',
  img: '/North Indian/poori_aloo_bhaji.jpeg',
  ingredients: [
    'For the poori: 2 cups whole wheat flour, water for kneading, oil for frying',
    'For the aloo bhaji: 4 potatoes, boiled and cubed',
    '1 onion, chopped',
    '2 green chilies, chopped',
    '1 tsp mustard seeds',
    '1 tsp turmeric powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'To prepare the poori, knead the whole wheat flour with water into a firm dough. Roll into small discs and deep-fry until golden brown.',
    'For the aloo bhaji, heat oil in a pan, add mustard seeds and let them splutter.',
    'Add onions and green chilies, and sauté until soft.',
    'Add turmeric powder, boiled potatoes, and salt. Mix well and cook for a few minutes.',
    'Garnish with fresh coriander and serve hot with poori.'
  ],
  video: 'https://youtu.be/XAzFAsiMeTI?feature=shared'
},
{
  name: 'Poori Aloo Matar Bhaji',
  img: '/North Indian/poori_aloo_matar_bhaji.jpeg',
  ingredients: [
    'For the poori: 2 cups whole wheat flour, water for kneading, oil for frying',
    'For the aloo matar bhaji: 2 potatoes, cubed',
    '1 cup green peas (matar)',
    '1 onion, chopped',
    '2 green chilies, chopped',
    '1 tsp mustard seeds',
    '1 tsp turmeric powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'To prepare the poori, knead the whole wheat flour with water into a firm dough. Roll into small discs and deep-fry until golden brown.',
    'For the aloo matar bhaji, heat oil in a pan, add mustard seeds and let them splutter.',
    'Add onions and green chilies, and sauté until soft.',
    'Add turmeric powder, potatoes, green peas, and salt. Mix well and cook for a few minutes.',
    'Garnish with fresh coriander and serve hot with poori.'
  ],
  video: 'https://youtu.be/AuBzQN1a1Ww?feature=shared'
},
{
  name: 'Potato Aloo Gobi',
  img: '/North Indian/potato_aloo_gobi.jpeg',
  ingredients: [
    '2 potatoes, cubed',
    '1 small cauliflower, cut into florets',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tbsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices, and cook until the oil separates.',
    'Add potatoes and cauliflower florets, and cook on low heat until tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/JihdOvkxQC8?feature=shared'
},
{
  name: 'Rice Dal Fry',
  img: '/North Indian/rice_dal_fry.jpeg',
  ingredients: [
    '1 cup basmati rice',
    '1/2 cup yellow moong dal',
    '1 onion, chopped',
    '1 tomato, chopped',
    '1 tsp cumin seeds',
    '1 tsp mustard seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp garam masala',
    '2 green chilies, chopped',
    '1 tbsp ginger-garlic paste',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Cook basmati rice and set aside.',
    'Rinse and cook moong dal until soft and mushy.',
    'Heat oil in a pan, add cumin and mustard seeds, and let them splutter.',
    'Add onions and green chilies, and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, turmeric powder, red chili powder, and garam masala; cook until the tomatoes turn soft.',
    'Add the cooked moong dal and adjust the salt. Simmer for a few minutes.',
    'Serve the dal fry with the cooked rice, garnished with fresh coriander.'
  ],
  video: 'https://youtu.be/r9BBNT3vOGw?feature=shared'
},
{
  name: 'Roti',
  img: '/North Indian/roti.jpeg',
  ingredients: [
    '2 cups whole wheat flour',
    'Water, for kneading',
    'Salt (optional)',
    'Ghee or butter (optional, for brushing)'
  ],
  instructions: [
    'In a bowl, mix whole wheat flour with water to form a smooth dough. Add a pinch of salt if desired.',
    'Divide the dough into small portions and roll each into a thin circle.',
    'Heat a tawa or skillet and cook the roti on both sides until light brown spots appear.',
    'Optional: Brush the cooked roti with ghee or butter before serving.'
  ],
  video: 'https://youtu.be/jnQgkwVsMgc?feature=shared'
},
{
  name: 'Samosa Green Chutney',
  img: '/North Indian/samosa_green_chutney.jpeg',
  ingredients: [
    'For the samosa dough: 2 cups all-purpose flour, 1/4 cup oil, water for kneading, salt to taste',
    'For the filling: 4 potatoes, boiled and mashed, 1/2 cup green peas, 1 tsp cumin seeds, 1 tsp turmeric powder, 1 tsp garam masala, 1 tsp coriander powder, Salt to taste, Oil for frying',
    'For the green chutney: 1 cup fresh coriander leaves, 1/2 cup fresh mint leaves, 2 green chilies, 1 tbsp lemon juice, Salt to taste'
  ],
  instructions: [
    'To prepare the samosa dough, mix all-purpose flour, oil, and salt, and add water to form a firm dough. Let it rest for 20 minutes.',
    'For the filling, heat oil in a pan, add cumin seeds, then sauté mashed potatoes, peas, and spices until well mixed. Let the mixture cool.',
    'Divide the dough into balls, roll each into a circle, cut in half, and shape each half into a cone. Fill with the potato mixture and seal the edges.',
    'Deep-fry the samosas until golden brown.',
    'For the green chutney, blend coriander, mint, green chilies, lemon juice, and salt to form a smooth paste. Serve with the samosas.'
  ],
  video: 'https://youtu.be/Dn8mPRbIq-w?feature=shared'
},
{
  name: 'Masala Potato',
  img: '/Gujarati/masala potato.jpeg',
  ingredients: [
    '4 large potatoes, peeled and cubed',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp mustard seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin and mustard seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft and oil starts separating.',
    'Add potatoes and mix well. Cover and cook on low heat until potatoes are tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/ncD_3gaRKbM?feature=shared'
},
{
  name: 'Masala Khichdi',
  img: '/Gujarati/masala khichdi.jpeg',
  ingredients: [
    '1 cup rice',
    '1/2 cup moong dal',
    '1 onion, chopped',
    '1 tomato, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp garam masala',
    '1 tsp red chili powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Rinse rice and moong dal together and set aside.',
    'Heat oil in a pressure cooker, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add rice, moong dal, and enough water. Stir well and pressure cook for 2-3 whistles.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/yTDstGmWl_k?feature=shared'
},
{
  name: 'Dal Fry',
  img: '/Gujarati/dal fry.jpeg',
  ingredients: [
    '1 cup toor dal',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp mustard seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Rinse and cook toor dal until soft.',
    'Heat oil in a pan, add cumin and mustard seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until the tomatoes are soft.',
    'Add cooked dal and mix well. Simmer for a few minutes.',
    'Garnish with fresh coriander and serve hot with rice or roti.'
  ],
  video: 'https://youtu.be/kfgrqTRQ1kM?feature=shared'
},
{
  name: 'Chapati Butter',
  img: '/Gujarati/chapati butter.jpeg',
  ingredients: [
    '2 cups whole wheat flour',
    'Water for kneading',
    'Salt to taste',
    'Butter for serving'
  ],
  instructions: [
    'In a bowl, mix whole wheat flour with water to form a smooth dough. Add a pinch of salt if desired.',
    'Divide the dough into small portions and roll each into a thin circle.',
    'Heat a tawa or skillet and cook the chapati on both sides until light brown spots appear.',
    'Brush with butter while hot and serve with your choice of curry or sabzi.'
  ],
  video: 'https://youtu.be/Iohqkf59k3E?feature=shared'
},
{
  name: 'Bhindi',
  img: '/Gujarati/bhindi.jpeg',
  ingredients: [
    '500 g bhindi (okra), chopped',
    '1 onion, chopped',
    '1 tomato, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add chopped bhindi and mix well. Cook on low heat until bhindi is tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/yDLPnEMzvYA?feature=shared'
},
{
  name: 'Aloo Gobi',
  img: '/Gujarati/aloo gobi.jpeg',
  ingredients: [
    '2 potatoes, cubed',
    '1 small cauliflower, cut into florets',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add potatoes and cauliflower, and mix well. Cook until tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/JihdOvkxQC8?feature=shared'
},
{
  name: 'Mix Vegetable',
  img: '/Gujarati/mix vegetable.jpeg',
  ingredients: [
    '1 cup mixed vegetables (carrots, beans, peas, potatoes)',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add mixed vegetables and mix well. Cook until the vegetables are tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/sm_Pp_pjrnk?feature=shared'
},
{
  name: 'Moong Butter Masala',
  img: '/Gujarati/moong butter masala.jpeg',
  ingredients: [
    '1 cup moong dal',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Butter for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Rinse and cook moong dal until soft.',
    'Heat butter in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add cooked moong dal and mix well. Simmer for a few minutes.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/gOHzDElkxEM?feature=shared'
},
{
  name: 'Patta Gobi',
  img: '/Gujarati/patta gobi.jpeg',
  ingredients: [
    '1 small cabbage, shredded',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add shredded cabbage and mix well. Cook until the cabbage is tender.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/OzUlR8BVmOE?feature=shared'
},
{
  name: 'Potato Curry',
  img: '/Gujarati/potato curry.jpeg',
  ingredients: [
    '4 potatoes, peeled and cubed',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp garam masala',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add potatoes and mix well. Cook until potatoes are tender and the gravy thickens.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/bYHC_SHprnU?feature=shared'
},
{
  name: 'Sev Tameta',
  img: '/Gujarati/sev tameta.jpeg',
  ingredients: [
    '4 tomatoes, chopped',
    '1 onion, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Sev (crunchy chickpea noodles) for garnish'
  ],
  instructions: [
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Simmer until the gravy thickens. Adjust seasoning if needed.',
    'Garnish with sev and serve hot.'
  ],
  video: 'https://youtu.be/d_T2-lZM1oY?feature=shared'
},
{
  name: 'Totha Tuver',
  img: '/Gujarati/totha tuver.jpeg',
  ingredients: [
    '1 cup toor dal',
    '1 onion, chopped',
    '2 tomatoes, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Rinse and cook toor dal until soft.',
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add cooked toor dal and mix well. Simmer for a few minutes.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/VIilhRPXKvE?feature=shared'
},
{
  name: 'Patra',
  img: '/Gujarati/patra.jpeg',
  ingredients: [
    '1 cup colocasia leaves',
    '1 cup besan (chickpea flour)',
    '1 tbsp ginger-garlic paste',
    '1 tsp turmeric powder',
    '1 tsp red chili powder',
    '1 tsp coriander powder',
    '1 tsp cumin seeds',
    'Salt to taste',
    'Oil for cooking'
  ],
  instructions: [
    'Mix besan with spices and water to form a thick batter.',
    'Spread the batter on colocasia leaves, roll tightly, and steam for 20-30 minutes.',
    'Slice the steamed roll and shallow fry until crispy.',
    'Serve hot.'
  ],
  video: 'https://youtu.be/8mHSZuieL9w?feature=shared'
},
{
  name: 'Pulao',
  img: '/Gujarati/pulla.jpeg',
  ingredients: [
    '1 cup basmati rice',
    '1/2 cup mixed vegetables (carrots, peas, beans)',
    '1 onion, chopped',
    '1 tsp ginger-garlic paste',
    '1 tsp cumin seeds',
    '1 tsp turmeric powder',
    '1 tsp garam masala',
    '1 tsp red chili powder',
    'Salt to taste',
    'Oil for cooking',
    'Fresh coriander for garnish'
  ],
  instructions: [
    'Rinse and soak basmati rice for 30 minutes.',
    'Heat oil in a pan, add cumin seeds, and let them splutter.',
    'Add onions and sauté until golden brown.',
    'Add ginger-garlic paste, vegetables, and spices; cook for a few minutes.',
    'Add rice and water. Bring to a boil, then cover and simmer until rice is cooked.',
    'Garnish with fresh coriander and serve hot.'
  ],
  video: 'https://youtu.be/nPi2GD2SqfQ?feature=shared'
},
{
  name: 'Thepla Dahi Masala',
  img: '/Gujarati/thepla dahi masala.jpeg',
  ingredients: [
    'For the Thepla: 1 cup whole wheat flour, 1/2 cup besan (chickpea flour), 1/2 cup yogurt, 1/2 tsp turmeric powder, 1/2 tsp red chili powder, 1/2 tsp cumin seeds, Salt to taste',
    'For the Dahi Masala: 1 cup yogurt, 1 onion, chopped, 2 tomatoes, chopped, 1 tsp ginger-garlic paste, 1 tsp cumin seeds, 1 tsp turmeric powder, 1 tsp red chili powder, 1 tsp garam masala, Salt to taste'
  ],
  instructions: [
    'For the Thepla: Mix all ingredients to form a smooth dough. Roll into thin circles and cook on a hot tawa until golden brown on both sides.',
    'For the Dahi Masala: Heat oil in a pan, add cumin seeds, and let them splutter. Add onions and sauté until golden brown. Add ginger-garlic paste, tomatoes, and spices; cook until tomatoes are soft.',
    'Add yogurt and simmer for a few minutes. Serve with thepla.'
  ],
  video: 'https://youtu.be/RK9yrAI9RJ0?feature=shared'
},
{
  name: 'Thepla Garlic',
  img: '/Gujarati/thepla_garlic.jpg',
  ingredients: [
    '1 cup whole wheat flour',
    '1/4 cup besan (chickpea flour)',
    '1/4 cup finely chopped garlic',
    '1/2 cup yogurt',
    '1/2 tsp turmeric powder',
    '1/2 tsp red chili powder',
    '1/2 tsp cumin seeds',
    'Salt to taste',
    'Oil for cooking'
  ],
  instructions: [
    'Mix all ingredients to form a smooth dough. Roll into thin circles and cook on a hot tawa until golden brown on both sides.',
    'Serve hot with yogurt or pickle.'
  ],
  video: 'https://youtu.be/oSFgRLODqEw?feature=shared'
},
{
  name: 'White Dhokla',
  img: '/Gujarati/white dhokla.jpg',
  ingredients: [
    '1 cup rice',
    '1/2 cup urad dal',
    '1/2 cup yogurt',
    '1 tsp mustard seeds',
    '1 tsp sesame seeds',
    '1 tsp turmeric powder',
    '1 tsp baking soda',
    'Salt to taste',
    'Oil for greasing'
  ],
  instructions: [
    'Soak rice and urad dal overnight, then grind into a smooth batter.',
    'Mix yogurt, turmeric powder, and salt into the batter.',
    'Pour batter into a greased steaming tray and steam for 15-20 minutes.',
    'Heat oil in a pan, add mustard seeds and sesame seeds, and let them splutter. Pour over the steamed dhokla.',
    'Cut into pieces and serve hot.'
  ],
  video: 'https://youtu.be/RWfN0--2NZ4?feature=shared'
},
{
  name: 'Dhokla Vati Dal Naylon',
  img: '/Gujarati/dhokla_vati_dal_naylon.jpeg',
  ingredients: [
    '1 cup dhokla batter',
    '1/2 cup urad dal',
    '1/2 cup chopped vegetables (carrots, peas)',
    '1 tsp mustard seeds',
    '1 tsp sesame seeds',
    '1 tsp turmeric powder',
    '1 tsp baking soda',
    'Salt to taste',
    'Oil for greasing'
  ],
  instructions: [
    'Soak urad dal overnight, then grind into a smooth batter.',
    'Mix dhokla batter with urad dal, turmeric powder, and salt.',
    'Pour batter into a greased steaming tray and steam for 20-25 minutes.',
    'Heat oil in a pan, add mustard seeds and sesame seeds, and let them splutter. Pour over the steamed dhokla.',
    'Cut into pieces and serve hot.'
  ],
  video: 'https://youtu.be/FgXIA5fxqjo?feature=shared'
},
{
  name: 'Fafda',
  img: '/Gujarati/fafda.png',
  ingredients: [
    '1 cup besan (chickpea flour)',
    '1/4 cup rice flour',
    '1 tsp cumin seeds',
    '1/2 tsp turmeric powder',
    '1/2 tsp red chili powder',
    'Salt to taste',
    'Oil for frying'
  ],
  instructions: [
    'Mix besan, rice flour, cumin seeds, turmeric powder, red chili powder, and salt. Add water to form a smooth dough.',
    'Roll the dough into thin strips and cut into desired lengths.',
    'Heat oil in a pan, and deep-fry the strips until crispy and golden brown.',
    'Serve hot with chutney or pickle.'
  ],
  video: 'https://youtu.be/gNWW_46qJFA?feature=shared'
},
{
  name: 'Jalebi Pista',
  img: '/Gujarati/jalebi pista.jpeg',
  ingredients: [
    '1 cup all-purpose flour',
    '1/2 cup yogurt',
    '1/2 cup sugar',
    '1/2 cup water',
    '1/2 tsp baking powder',
    '1/4 tsp saffron strands',
    '1/4 cup chopped pistachios',
    'Oil for frying'
  ],
  instructions: [
    'Mix flour, yogurt, and baking powder to form a batter. Let it rest for a few hours.',
    'Heat oil in a pan for deep frying.',
    'Fill a piping bag with batter and squeeze into hot oil in circular shapes.',
    'Fry until golden brown, then dip in a sugar syrup flavored with saffron.',
    'Garnish with chopped pistachios and serve hot.'
  ],
  video: 'https://youtu.be/iQqWWO0c2zs?feature=shared'
},
{
  name: 'Paneer Naylon Dhokla',
  img: '/Gujarati/paneer naylon dhokla.jpeg',
  ingredients: [
    '1 cup rice',
    '1/2 cup urad dal',
    '1/2 cup grated paneer',
    '1/2 cup yogurt',
    '1 tsp mustard seeds',
    '1 tsp sesame seeds',
    '1 tsp turmeric powder',
    '1 tsp baking soda',
    'Salt to taste',
    'Oil for greasing'
  ],
  instructions: [
    'Soak rice and urad dal overnight, then grind into a smooth batter.',
    'Mix yogurt, turmeric powder, salt, and grated paneer into the batter.',
    'Pour batter into a greased steaming tray and steam for 15-20 minutes.',
    'Heat oil in a pan, add mustard seeds and sesame seeds, and let them splutter. Pour over the steamed dhokla.',
    'Cut into pieces and serve hot.'
  ],
  video: 'https://youtu.be/yW6KRTEfveY?feature=shared'
},

  {
    name: 'Onion Rava Masala Dosa',
    img: '/South Indian/onion rava masala dosa.jpeg',
    ingredients: [
      '1 cup rava (semolina)',
      '1/2 cup rice flour',
      '1/2 cup yogurt',
      '1 onion, finely chopped',
      '1 green chili, finely chopped',
      '1 tsp mustard seeds',
      '1 tsp cumin seeds',
      '1 tsp turmeric powder',
      '1 tsp red chili powder',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Mix rava, rice flour, and yogurt to form a smooth batter. Let it sit for 15 minutes.',
      'Heat oil in a pan, add mustard seeds and cumin seeds. Add onions and green chili, and sauté until onions are golden brown.',
      'Add turmeric powder, red chili powder, and salt. Mix well.',
      'Heat a non-stick tawa, pour a ladle of batter, and spread it into a thin dosa. Cook until crispy and golden brown.',
      'Add the onion mixture on one half of the dosa, fold, and serve hot.'
    ],
    video: 'https://youtu.be/_g9HsPRdWUc?feature=shared '
  },
  {
    name: 'Medu Vada',
    img: '/South Indian/medu vada.jpeg',
    ingredients: [
      '1 cup urad dal',
      '1 onion, finely chopped',
      '2 green chilies, finely chopped',
      '1 tsp ginger, finely chopped',
      '1/2 tsp cumin seeds',
      '1/2 tsp black pepper',
      'Salt to taste',
      'Oil for frying'
    ],
    instructions: [
      'Soak urad dal in water for 4-5 hours, then drain.',
      'Grind dal to a smooth batter, adding a little water if needed.',
      'Mix in onions, green chilies, ginger, cumin seeds, black pepper, and salt.',
      'Heat oil in a pan. Shape the batter into small donuts and fry until golden brown and crispy.',
      'Drain on paper towels and serve hot with coconut chutney and sambar.'
    ],
    video: 'https://youtu.be/Zjm9fQBBHiM?feature=shared'
  },
  {
    name: 'Idli',
    img: '/South Indian/idli.jpeg',
    ingredients: [
      '1 cup urad dal',
      '2 cups idli rice',
      '1/2 tsp fenugreek seeds',
      'Salt to taste',
      'Water as needed'
    ],
    instructions: [
      'Soak urad dal and fenugreek seeds in water for 4-5 hours.',
      'Soak idli rice separately in water for 4-5 hours.',
      'Grind urad dal and fenugreek seeds to a smooth batter, then grind idli rice coarsely.',
      'Mix both batters, add salt, and let the batter ferment overnight.',
      'Pour batter into idli molds and steam for 10-12 minutes.',
      'Serve hot with coconut chutney and sambar.'
    ],
    video: 'https://youtu.be/Ayo80PIb-Qg?feature=shared'
  },
  {
    name: 'Dosa',
    img: '/South Indian/dosa.jpeg',
    ingredients: [
      '1 cup dosa rice',
      '1/4 cup urad dal',
      '1/4 cup chana dal',
      '1/2 tsp fenugreek seeds',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Soak dosa rice, urad dal, chana dal, and fenugreek seeds in water for 4-5 hours.',
      'Drain and grind to a smooth batter, adding water as needed.',
      'Mix in salt and let the batter ferment overnight.',
      'Heat a non-stick tawa, pour a ladle of batter, and spread it into a thin circle. Cook until crispy and golden brown.',
      'Serve hot with chutney and sambar.'
    ],
    video: 'https://youtu.be/PFG1aeYgi7c?feature=shared'
  },
  {
    name: 'Cheese Gotala Dosa',
    img: '/South Indian/cheese gotala dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1/2 cup grated cheese',
      '1 onion, finely chopped',
      '1 green chili, finely chopped',
      '1 tsp cumin seeds',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Heat oil in a pan, add cumin seeds, and let them splutter. Add onions and green chili, and sauté until onions are golden brown.',
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Sprinkle grated cheese and the onion mixture on top. Cook until cheese is melted and dosa is crispy.',
      'Serve hot.'
    ],
    video: 'https://youtu.be/ASoa99Im65M?feature=shared'
  },
  {
    name: 'Butter Masala Dosa',
    img: '/South Indian/butter masala dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1 cup potato masala (prepared separately)',
      'Butter for cooking',
      'Salt to taste'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Cook until crispy and golden brown.',
      'Spread a layer of butter on the dosa, and add a portion of potato masala on one half of the dosa.',
      'Fold the dosa and serve hot.'
    ],
    video: 'https://youtu.be/hlKIRHo7HRo?feature=shared'
  },
  {
    name: 'Rava Dosa',
    img: '/South Indian/rava dosa.jpeg',
    ingredients: [
      '1 cup rava (semolina)',
      '1/2 cup rice flour',
      '1/2 cup yogurt',
      '1 onion, finely chopped',
      '1 green chili, finely chopped',
      '1 tsp cumin seeds',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Mix rava, rice flour, and yogurt to form a smooth batter. Let it sit for 15 minutes.',
      'Add onions, green chili, and cumin seeds to the batter.',
      'Heat a non-stick tawa, pour a ladle of batter, and spread it into a thin circle.',
      'Cook until crispy and golden brown on both sides.',
      'Serve hot with chutney and sambar.'
    ],
    video: 'https://youtu.be/sX5pYdNbmgo?feature=shared'
  },
  {
    name: 'Paneer Gotala Dosa',
    img: '/South Indian/paneer gotala dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1/2 cup grated paneer',
      '1 onion, finely chopped',
      '1 green chili, finely chopped',
      '1 tsp cumin seeds',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Heat oil in a pan, add cumin seeds, and let them splutter. Add onions and green chili, and sauté until onions are golden brown.',
      'Add grated paneer and cook for a few minutes.',
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Add the paneer mixture on one half of the dosa, fold, and cook until crispy and golden brown.',
      'Serve hot.'
    ],
    video: 'https://youtu.be/ePfR9C4dNWM?feature=shared'
  },
  {
    name: 'Upma',
    img: '/South Indian/upma.jpeg',
    ingredients: [
      '1 cup rava (semolina)',
      '1 onion, chopped',
      '1 green chili, chopped',
      '1 tsp mustard seeds',
      '1 tsp cumin seeds',
      '1/2 tsp turmeric powder',
      '1/2 tsp red chili powder',
      'Salt to taste',
      'Oil for cooking',
      'Fresh coriander for garnish'
    ],
    instructions: [
      'Roast rava in a pan until slightly golden and set aside.',
      'Heat oil in a pan, add mustard seeds and cumin seeds, and let them splutter.',
      'Add onions and green chili, and sauté until onions are golden brown.',
      'Add turmeric powder, red chili powder, and salt.',
      'Add water and bring it to a boil. Gradually add roasted rava while stirring continuously.',
      'Cover and cook for a few minutes until rava is cooked through.',
      'Garnish with fresh coriander and serve hot.'
    ],
    video: 'https://youtu.be/FDzZfwOXqqQ?feature=shared'
  },
  {
    name: 'Uttapam',
    img: '/South Indian/uttapam.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1 onion, finely chopped',
      '1 tomato, finely chopped',
      '1 green chili, finely chopped',
      '1 tsp cumin seeds',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thick circle.',
      'Top with onions, tomatoes, green chilies, and cumin seeds.',
      'Cook until the bottom is golden brown and the toppings are cooked.',
      'Serve hot with chutney and sambar.'
    ],
    video: 'https://youtu.be/BiO1SXyRAs4?feature=shared'
  },
  {
    name: 'Tikdi Vada',
    img: '/South Indian/tikdi_vada.jpeg',
    ingredients: [
      '1 cup urad dal',
      '1/2 cup chana dal',
      '1 onion, finely chopped',
      '2 green chilies, finely chopped',
      '1 tsp cumin seeds',
      '1 tsp black pepper',
      'Salt to taste',
      'Oil for frying'
    ],
    instructions: [
      'Soak urad dal and chana dal in water for 4-5 hours, then drain.',
      'Grind the dal to a smooth batter, adding a little water if needed.',
      'Mix in onions, green chilies, cumin seeds, black pepper, and salt.',
      'Heat oil in a pan. Shape the batter into small disks and fry until golden brown.',
      'Drain on paper towels and serve hot with coconut chutney.'
    ],
    video: 'https://youtu.be/uaSKJ49ohuM?feature=shared'
  },
  {
    name: 'Paper Masala Dosa',
    img: '/South Indian/paper_masala_dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1 cup potato masala (prepared separately)',
      'Butter for cooking',
      'Salt to taste'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a very thin circle.',
      'Cook until crispy and golden brown.',
      'Spread a layer of butter on the dosa, and add a portion of potato masala on one half of the dosa.',
      'Fold the dosa and serve hot.'
    ],
    video: 'https://youtu.be/TchusZkUyRE?feature=shared'
  },
  {
    name: 'Masala Spicy Idli',
    img: '/South Indian/masala_spicy_idli.jpeg',
    ingredients: [
      '10 idlis (prepared separately)',
      '2 tbsp oil',
      '1 onion, chopped',
      '1 green chili, chopped',
      '1 tsp mustard seeds',
      '1 tsp urad dal',
      '1 tsp chana dal',
      '1/2 tsp turmeric powder',
      '1/2 tsp red chili powder',
      'Salt to taste',
      'Fresh coriander for garnish'
    ],
    instructions: [
      'Cut idlis into small pieces.',
      'Heat oil in a pan, add mustard seeds, urad dal, and chana dal, and let them splutter.',
      'Add onions and green chili, and sauté until onions are golden brown.',
      'Add turmeric powder, red chili powder, and salt. Mix well.',
      'Add idli pieces and cook until they are crispy and coated with the spices.',
      'Garnish with fresh coriander and serve hot.'
    ],
    video: 'https://youtu.be/8RhPnQsBKxs?feature=shared'
  },
  {
    name: 'Masala Idli',
    img: '/South Indian/masala_idali.jpeg',
    ingredients: [
      '10 idlis (prepared separately)',
      '2 tbsp oil',
      '1 onion, chopped',
      '1 green chili, chopped',
      '1 tsp mustard seeds',
      '1 tsp urad dal',
      '1 tsp chana dal',
      '1/2 tsp turmeric powder',
      '1/2 tsp red chili powder',
      'Salt to taste',
      'Fresh coriander for garnish'
    ],
    instructions: [
      'Cut idlis into small pieces.',
      'Heat oil in a pan, add mustard seeds, urad dal, and chana dal, and let them splutter.',
      'Add onions and green chili, and sauté until onions are golden brown.',
      'Add turmeric powder, red chili powder, and salt. Mix well.',
      'Add idli pieces and cook until they are crispy and coated with the spices.',
      'Garnish with fresh coriander and serve hot.'
    ],
    video: 'https://youtu.be/ancrxXnFBfQ?feature=shared'
  },
  {
    name: 'Masala Dosa',
    img: '/South Indian/masala_dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1 cup potato masala (prepared separately)',
      'Butter for cooking',
      'Salt to taste'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Cook until crispy and golden brown.',
      'Spread a layer of butter on the dosa, and add a portion of potato masala on one half of the dosa.',
      'Fold the dosa and serve hot.'
    ],
    video: 'https://youtu.be/J75VQSxOtdo?feature=shared'
  },
  {
    name: 'Idli Mix',
    img: '/South Indian/idli_mix.jpeg',
    ingredients: [
      '1 cup idli batter',
      '1/4 cup finely chopped vegetables (carrots, beans, peas)',
      'Salt to taste'
    ],
    instructions: [
      'Mix the chopped vegetables into the idli batter.',
      'Pour batter into idli molds and steam for 10-12 minutes.',
      'Serve hot with coconut chutney and sambar.'
    ],
    video: 'https://youtu.be/-qvREddg-a8?feature=shared'
  },
  {
    name: 'Idli Garlic',
    img: '/South Indian/idali_garlic.jpeg',
    ingredients: [
      '10 idlis (prepared separately)',
      '2 tbsp oil',
      '1/4 cup garlic, finely chopped',
      '1/4 cup fresh coriander, chopped',
      'Salt to taste'
    ],
    instructions: [
      'Heat oil in a pan, add garlic, and sauté until golden brown.',
      'Cut idlis into small pieces and add to the pan.',
      'Mix well, add salt, and cook until idlis are crispy.',
      'Garnish with fresh coriander and serve hot.'
    ],
    video: 'https://youtu.be/BO7ndnPc-IA?feature=shared'
  },
  {
    name: 'Dal Sambhar',
    img: '/South Indian/dali_sambhar.jpeg',
    ingredients: [
      '1 cup toor dal',
      '1 onion, chopped',
      '1 tomato, chopped',
      '1/2 cup mixed vegetables (carrots, beans, potatoes)',
      '1 tbsp sambhar powder',
      '1 tsp mustard seeds',
      '1 tsp cumin seeds',
      '1/2 tsp turmeric powder',
      'Salt to taste',
      'Oil for cooking'
    ],
    instructions: [
      'Cook toor dal in a pressure cooker until soft.',
      'Heat oil in a pan, add mustard seeds and cumin seeds, and let them splutter.',
      'Add onions, tomatoes, and mixed vegetables, and cook until vegetables are tender.',
      'Add sambhar powder, turmeric powder, and salt. Mix well.',
      'Add cooked dal and simmer for 10 minutes.',
      'Serve hot with rice or dosa.'
    ],
    video: 'https://youtu.be/EkJC0GgY5wk?feature=shared'
  },
  {
    name: 'Cheese Masala Paneer Dosa',
    img: '/South Indian/cheese_masala_paneer_dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1/2 cup grated cheese',
      '1 cup potato masala (prepared separately)',
      '1/2 cup paneer, cubed',
      'Butter for cooking',
      'Salt to taste'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Add grated cheese, potato masala, and paneer cubes on one half of the dosa.',
      'Cook until crispy and the cheese is melted.',
      'Fold the dosa and serve hot.'
    ],
    video: 'https://youtu.be/_1udh4utn20?feature=shared'
  },
  {
    name: 'Aloo Masala Dosa',
    img: '/South Indian/aloo masala dosa.jpeg',
    ingredients: [
      '1 cup dosa batter',
      '1 cup potato masala (prepared separately)',
      'Butter for cooking',
      'Salt to taste'
    ],
    instructions: [
      'Heat a non-stick tawa, pour a ladle of dosa batter, and spread it into a thin circle.',
      'Cook until crispy and golden brown.',
      'Spread a layer of butter on the dosa, and add a portion of potato masala on one half of the dosa.',
      'Fold the dosa and serve hot.'
    ],
    video: 'https://youtu.be/mDqkxZ3UVzc?feature=shared'
  },
{
      name: "Schezwan Manchurian Rice",
      category: "Chinese",
      img: "/chinese/schezwan manchurian rice.jpeg",
      ingredients: [
        "2 cups cooked rice",
        "1 cup vegetable manchurian",
        "2 tbsp Schezwan sauce",
        "1 tbsp soy sauce",
        "1 tsp vinegar",
        "1 tbsp oil",
        "1 spring onion, chopped",
        "Salt to taste",
        "Pepper to taste",
      ],
      instructions: [
        "Heat oil in a pan and add spring onions.",
        "Add the Schezwan sauce, soy sauce, and vinegar.",
        "Add the vegetable manchurian and stir well.",
        "Add the cooked rice and mix thoroughly.",
        "Season with salt and pepper to taste.",
        "Serve hot.",
      ],
      video: "https://youtu.be/H5kB81doipk?si=pZ7-JRVaW5kaAZvG",
    },
    {
      id: 14,
      name: "Vegetable Manchurian Cheese Fried",
      category: "Chinese",
      img: "/chinese/vegetable manchurian cheese fried.jpeg",
      ingredients: [
        "1 cup vegetable manchurian",
        "1/2 cup cheese, grated",
        "1 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp oil",
        "Spring onions for garnish",
      ],
      instructions: [
        "Heat oil in a pan and add the vegetable manchurian.",
        "Add soy sauce and chili sauce, and stir well.",
        "Top with grated cheese and let it melt.",
        "Garnish with spring onions.",
        "Serve hot.",
      ],
      video: "https://www.youtube.com/watch?v=Tc2Qyl-Ryto",
    },
    {
      id: 15,
      name: "Dry Manchurian",
      category: "Chinese",
      img: "/chinese/dry manchurian.webp",
      ingredients: [
        "1 cup vegetable manchurian",
        "2 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp oil",
        "1 spring onion, chopped",
        "Salt to taste",
        "Pepper to taste",
      ],
      instructions: [
        "Heat oil in a pan and add the vegetable manchurian.",
        "Add soy sauce and chili sauce, and stir well.",
        "Season with salt and pepper.",
        "Serve hot.",
      ],
      video: "https://www.youtube.com/watch?v=ggnZP9fGlMw",
    },
    {
      id: 16,
      name: "Hakka Noodles",
      category: "Chinese",
      img: "/chinese/hakka noodles.jpeg",
      ingredients: [
        "200g noodles",
        "1 cup mixed vegetables (carrot, capsicum, beans)",
        "2 tbsp soy sauce",
        "1 tbsp vinegar",
        "1 tbsp oil",
        "1 tsp black pepper",
        "Spring onions for garnish",
      ],
      instructions: [
        "Cook the noodles as per the package instructions.",
        "Heat oil in a pan and add mixed vegetables.",
        "Add soy sauce and vinegar, and stir well.",
        "Add cooked noodles and mix thoroughly.",
        "Season with black pepper.",
        "Garnish with spring onions.",
        "Serve hot.",
      ],
      video: "https://youtu.be/4Q12_scB6AY?si=FhwsjIdiTFuD6WcI",
    },
    {
      id: 17,
      name: "Manchurian Bhel",
      category: "Chinese",
      img: "/chinese/manchurian bhel.jpeg",
      ingredients: [
        "1 cup vegetable manchurian",
        "1 cup puffed rice",
        "1/2 cup chopped onions",
        "1/2 cup chopped tomatoes",
        "1 tbsp tamarind chutney",
        "1 tbsp sweet chutney",
        "Chopped coriander for garnish",
      ],
      instructions: [
        "Mix the puffed rice with chopped onions and tomatoes.",
        "Add the vegetable manchurian and mix well.",
        "Add tamarind chutney and sweet chutney.",
        "Garnish with chopped coriander.",
        "Serve immediately.",
      ],
      video: "https://www.youtube.com/watch?v=YVubn1ZkpBY",
    },
    {
      id: 18,
      name: "Manchurian Cheese Fried",
      category: "Chinese",
      img: "/Chinese/vegetable manchurian cheese fried.jpeg",
      ingredients: [
        "1 cup vegetable manchurian",
        "1/2 cup cheese, grated",
        "1 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp oil",
        "Spring onions for garnish",
      ],
      instructions: [
        "Heat oil in a pan and add the vegetable manchurian.",
        "Add soy sauce and chili sauce, and stir well.",
        "Top with grated cheese and let it melt.",
        "Garnish with spring onions.",
        "Serve hot.",
      ],
      video: "https://www.youtube.com/watch?v=ZSPv5h4SJcE",
    },
    {
      id: 19,
      name: "Manchurian Gravy",
      category: "Chinese",
      img: "/chinese/manchurian gravy.jpeg",
      ingredients: [
        "1 cup vegetable manchurian",
        "1 cup water",
        "2 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp cornflour",
        "1 tbsp oil",
        "Spring onions for garnish",
      ],
      instructions: [
        "Heat oil in a pan and add soy sauce and chili sauce.",
        "Add water and bring to a boil.",
        "Mix cornflour with a little water and add to the pan.",
        "Add the vegetable manchurian and simmer for a few minutes.",
        "Garnish with spring onions.",
        "Serve hot with rice or noodles.",
      ],
      video: "https://youtu.be/2-uu7l3Qwuo?si=eymA4stcKHLaxM_9",
    },
    {
      id: 20,
      name: "Manchurian Noodles",
      category: "Chinese",
      img: "/chinese/manchurian noodles.jpg",
      ingredients: [
        "200g noodles",
        "1 cup vegetable manchurian",
        "2 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp oil",
        "Spring onions for garnish",
      ],
      instructions: [
        "Cook the noodles as per the package instructions.",
        "Heat oil in a pan and add the vegetable manchurian.",
        "Add soy sauce and chili sauce, and stir well.",
        "Add cooked noodles and mix thoroughly.",
        "Garnish with spring onions.",
        "Serve hot.",
      ],
      video: "https://www.youtube.com/watch?v=FmHCL7LUydU",
    },
    {
      id: 21,
      name: "Manchurian Paneer Dry",
      category: "Chinese",
      img: "/Chinese/manchurian paneer dry.webp",
      ingredients: [
        "1 cup paneer cubes",
        "1/2 cup vegetable manchurian",
        "2 tbsp soy sauce",
        "1 tbsp chili sauce",
        "1 tbsp oil",
        "Spring onions for garnish",
        "Salt to taste",
        "Pepper to taste",
      ],
      instructions: [
        "Heat oil in a pan and add the paneer cubes.",
        "Add soy sauce and chili sauce, and stir well.",
        "Add vegetable manchurian and mix thoroughly.",
        "Season with salt and pepper.",
        "Garnish with spring onions.",
        "Serve hot.",
      ],
      video: "https://youtube.com/shorts/wJjTswzNB6o?si=heobhujvBTzaQbYb",
    },
  ];

  const getVideoId = (url) => {
    const urlParams = new URLSearchParams(new URL(url).search);
    const videoId = urlParams.get('v') || url.split('/').pop();
    return videoId.includes('embed') ? url.split('/').pop() : videoId;
  };
  
  const RecipeDetails = () => {
    const { name } = useParams();
    const navigate = useNavigate();
  
    const recipe = Object.values(recipes)
      .flat()
      .find((recipe) => recipe.name === name);
  
    if (!recipe) {
      return <h2>Recipe not found</h2>;
    }
  
    const shareOnWhatsApp = () => {
      const shareText = `Check out this recipe: ${recipe.name}!\n\nIngredients:\n${recipe.ingredients.join(
        '\n'
      )}\n\nInstructions:\n${recipe.instructions.join(
        '\n'
      )}\n\nWatch the video here: ${recipe.video}`;
      const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
      window.open(url, '_blank');
    };
  
    const shareOnFacebook = () => {
      const shareText = `Check out this recipe: ${recipe.name}!\n\nIngredients:\n${recipe.ingredients.join(
        '\n'
      )}\n\nInstructions:\n${recipe.instructions.join(
        '\n'
      )}\n\nWatch the video here: ${recipe.video}`;
      const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
        recipe.video
      )}&quote=${encodeURIComponent(shareText)}`;
      window.open(url, '_blank');
    };
  
    return (
      <div className="recipe-details">
        <button onClick={() => navigate(-1)} className="back-button">
          ← Back to Recipes
        </button>
        <h1>{recipe.name}</h1>
        <img src={recipe.img} alt={recipe.name} />
        <h3>Ingredients:</h3>
        <ul>
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))}
        </ul>
        <h3>Instructions:</h3>
        <ul>
          {recipe.instructions.map((step, index) => (
            <li key={index}>{step}</li>
          ))}
        </ul>
        {recipe.video && (
          <div className="video-box">
            <h3>Watch How To Make:</h3>
            <iframe
              width="560"
              height="315"
              src={`https://www.youtube.com/embed/${getVideoId(recipe.video)}`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        )}
        <div className="share-buttons">
          <button onClick={shareOnWhatsApp}>Share on WhatsApp</button>
          <button onClick={shareOnFacebook}>Share on Facebook</button>
        </div>
      </div>
    );
  };
  
  export default RecipeDetails;
  