import React from 'react';

function About() {
  return (
    <div className="about-container">
      <h2>About Food Recipe</h2>
      <p>
        Welcome to Food Recipe, your number one source for all things food. We're dedicated to providing you with the very best recipes, with a focus on simplicity, taste, and nutrition.
      </p>
      <p>
        Founded in 2024, Food Recipe has come a long way from its beginnings. When we first started out, our passion for cooking drove us to start this website so that Food Recipe can offer you the world's best recipes. We now serve customers all over the world and are thrilled that we're able to turn our passion into our own website.
      </p>
      <p>
        We hope you enjoy our recipes as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.
      </p>
      <p>
        Sincerely, <br/>
        The Food Recipe Team
      </p>
    </div>
  );
}

export default About;
