import React from "react";
import { Link, useNavigate } from 'react-router-dom';
import './Home.css';

function Home() {
    const images = [
        'rice.jpeg',
        'bg_2.jpeg',
        'Dosa.jpeg',
        'pg.jpeg',
        'p(1).jpeg',
        '7.jpeg',
        'upma.jpeg',
        'mp.jpeg',
        'rice.jpeg',
        'bg_2.jpeg',
        'Dosa.jpeg',
        'pg.jpeg',
        'p(1).jpeg',
        '7.jpeg',
        'upma.jpeg'
    ];

    const navigate = useNavigate();

    return (
        <div className="home-container">
            <header className="header-nav">
                <nav>
                    <ul>
                        <li><Link to="/login">Login</Link></li>
                        <li><Link to="/register">Register</Link></li>
                    </ul>
                </nav>
            </header>

            <div className="hero-section">
                <h1>Welcome to the Food-Recipe App</h1>
                <p>Discover, cook, and enjoy delicious recipes from around the world!</p>
            </div>

            <div className="marquee-slider">
                <div className="marquee-content">
                    {images.map((image, index) => (
                        <img key={index} src={image} alt={`Slide ${index + 1}`} className="slider-image" />
                    ))}
                </div>
            </div>

            <div className="intro-section">
                <p>
                    Discover a world of culinary delights with our Recipe App. Whether you're craving a spicy Punjabi dish, a delicate French pastry, or a fresh North Indian meal, our app offers a wide variety of recipes to suit every taste. Explore, cook, and enjoy!
                </p>
            </div>

            <div className="popular-recipes">
                <h2>Popular Recipes</h2>
                <div className="recipe-cards">
                    <div className="recipe-card">
                        <img src="rice.jpeg" alt="Rice and Dal" />
                        <p>Rice and Dal</p>
                    </div>
                    <div className="recipe-card">
                        <img src="Dosa.jpeg" alt="Dosa" />
                        <p>Dosa</p>
                    </div>
                    <div className="recipe-card">
                        <img src="mp.jpeg" alt="Matar Paneer" />
                        <p>Matar Paneer</p>
                    </div>
                </div>
            </div>

            <footer className="footer">
                <p>&copy; 2024 Food-Recipe App | All Rights Reserved</p>
                <div className="footer-links">
                    <Link to="/about">About Us</Link>
                    <Link to="/contact">Contact Us</Link>
                    <Link to="/privacy">Privacy Policy</Link>
                </div>
            </footer>
        </div>
    );
}

export default Home;
