import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './Home';
import Register from './Register';
import Login from './Login';
import Logout from './Logout'; 
import Recipe from './Recipe'; 
import Home1 from './Home1';
import './App.css';
import About from './About';
import RecipeDetail from './RecipeDetail';
import Favorites from './Favorites';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/recipe" element={<Recipe />} />
          <Route path="/home1" element={<Home1 />} />
          <Route path="/about" element={<About />} />
          <Route path="/recipe/:name" element={<RecipeDetail />} />
          <Route path="/favorites" element={<Favorites />} /> 
        </Routes>
      </div>
    </Router>
  );
}

export default App;
