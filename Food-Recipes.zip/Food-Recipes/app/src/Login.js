import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import './Login.css';

function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [emailErr, setEmailErr] = useState(false);
    const [passwordErr, setPasswordErr] = useState(false);

    const navigate = useNavigate();

    const loginHandler = async (e) => {
        e.preventDefault();

        if (!validateEmail(email)) {
            alert("Please enter a valid email.");
        } else if (password.length < 6) {
            alert("Password must be at least 6 characters long.");
        } else {
            try {
                const response = await axios.post('http://localhost:5000/auth/login', { email, password });

                if (response && response.data) {
                    localStorage.setItem('token', response.data.token);
                    alert("Login successful!");
                    navigate('/home1');
                } else {
                    alert("Unexpected response format from the server.");
                }
            } catch (error) {
                if (error.response && error.response.data) {
                    alert(error.response.data.msg);
                } else {
                    alert("An error occurred. Please try again.");
                }
            }
        }
    };

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }

    function emailHandler(e) {
        let item = e.target.value;
        if (!validateEmail(item)) {
            setEmailErr(true);
        } else {
            setEmailErr(false);
        }
        setEmail(item);
    }

    function passwordHandler(e) {
        let item = e.target.value;
        if (item.length < 6) {
            setPasswordErr(true);
        } else {
            setPasswordErr(false);
        }
        setPassword(item);
    }

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={loginHandler}>
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Email"
                        value={email}
                        onChange={emailHandler}
                        required
                    />
                    {emailErr && <span className="error">Please enter a valid email.</span>}
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Password"
                        value={password}
                        onChange={passwordHandler}
                        required
                    />
                    {passwordErr && <span className="error">Password must be at least 6 characters long.</span>}
                </div>

                <button type="submit">Login</button>
            </form>
        </div>
    );
}

export default Login;
