import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Home1.css';

function Home1() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredRecipes, setFilteredRecipes] = useState([
    { img: '/bg_3.jpeg', title: 'Hearty Soup' },
    { img: '/bg_1.jpeg', title: 'Fresh Salad' },
    { img: '/bg_2.jpeg', title: 'Delicious Pasta' },
    { img: '/Dosa.jpeg', title: 'Dosa' },
    { img: '/mp.jpeg', title: 'Matar Paneer' },
    { img: '/vd.jpeg', title: 'Vada Pav' },
    { img: '/pg.jpeg', title: 'Delicious Pasta' },
    { img: '/rice.jpeg', title: 'Rice And Dal' },
  ]);

  const navigate = useNavigate();

  const handleExploreClick = () => {
    navigate('/recipe');
  };

  const handleLogout = () => {
    navigate('/');
  };

  const handleSearchChange = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    const recipes = [
      { img: '/bg_3.jpeg', title: 'Hearty Soup' },
      { img: '/bg_1.jpeg', title: 'Fresh Salad' },
      { img: '/bg_2.jpeg', title: 'Delicious Pasta' },
      { img: '/Dosa.jpeg', title: 'Dosa' },
      { img: '/mp.jpeg', title: 'Matar Paneer' },
      { img: '/vd.jpeg', title: 'Vada Pav' },
      { img: '/pg.jpeg', title: 'Delicious Pasta' },
      { img: '/rice.jpeg', title: 'Rice And Dal' },
    ];

    const filtered = recipes.filter(recipe =>
      recipe.title.toLowerCase().includes(query)
    );

    setFilteredRecipes(filtered);
  };

  return (
    <div className="container">
      <header className="header-nav">
        <nav>
          <ul>
            <li><Link to="/about">About</Link></li>
            <li><button className="explore-recipes-button" onClick={handleExploreClick}>Explore Recipes</button></li>
            <li><button className="logout-button" onClick={handleLogout}>Logout</button></li>
          </ul>
        </nav>
      </header>

      <div className="welcome-section">
        <h2>Welcome to Food Recipe</h2>
        <p>
          Discover delicious recipes from around the world. Whether you're looking for quick and easy meals or gourmet dishes, we have something for everyone. Explore our categories and find your next favorite recipe!
        </p>
      </div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search for recipes..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="search-input"
        />
      </div>

      <div className="recipe-overview">
        <div className="recipe-box">
          {filteredRecipes.map((recipe, index) => (
            <div key={index} className="recipe-item">
              <img src={recipe.img} alt={recipe.title} />
              <p>{recipe.title}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home1;
